package sn.zeitune.oliveinsuranceauthservice.app.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.EmployeeRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.EmployeeResponse;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Employee;

import java.util.List;
import java.util.UUID;

public interface EmployeeService {


    EmployeeResponse createEmployee(EmployeeRequest request);
    EmployeeResponse updateEmployee(UUID uuid, EmployeeRequest request);
    EmployeeResponse getEmployeeByUuid(UUID uuid);
    Page<EmployeeResponse> searchEmployees(Specification<Employee> spec, Pageable pageable);
    List<EmployeeResponse> getAllByManagementEntity(UUID managementEntity);
    Page<EmployeeResponse> getAllByManagementEntity(UUID managementEntity, Pageable pageable);
}
