package sn.zeitune.oliveinsuranceauthservice.app.services.impl;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.EmployeeRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.EmployeeResponse;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Employee;
import sn.zeitune.oliveinsuranceauthservice.app.mappers.EmployeeMapper;
import sn.zeitune.oliveinsuranceauthservice.app.repositories.EmployeeRepository;
import sn.zeitune.oliveinsuranceauthservice.app.services.EmployeeService;
import sn.zeitune.oliveinsuranceauthservice.app.specifications.EmployeeSpecifications;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    @Override
    public EmployeeResponse createEmployee(EmployeeRequest request) {
        Employee employee = EmployeeMapper.map(request, new Employee());
        employee = employeeRepository.save(employee);
        return EmployeeMapper.map(employee);
    }

    @Override
    public EmployeeResponse updateEmployee(UUID uuid, EmployeeRequest request) {

        Employee employee = employeeRepository.findByUuid(uuid)
                .orElseThrow(() -> new RuntimeException("Employee not found for UUID: " + uuid));
        EmployeeMapper.map(request, employee);
        employee = employeeRepository.save(employee);
        return EmployeeMapper.map(employee);
    }

    @Override
    public EmployeeResponse getEmployeeByUuid(UUID uuid) {
        Employee employee = employeeRepository.findByUuid(uuid)
                .orElseThrow(() -> new RuntimeException("Employee not found for UUID: " + uuid));
        return EmployeeMapper.map(employee);
    }

    @Override
    public Page<EmployeeResponse> search(String firstName, String lastName, String email, Pageable pageable) {
        return employeeRepository
                .findAll(EmployeeSpecifications.withFilters(firstName, lastName, email), pageable)
                .map(EmployeeMapper::map);
    }

    @Override
    public List<EmployeeResponse> getAllByManagementEntity(UUID managementEntity) {
        List<Employee> employees = employeeRepository.findAllByManagementEntity(managementEntity);
        return employees.stream()
                .map(EmployeeMapper::map)
                .collect(Collectors.toList());
    }

    @Override
    public Page<EmployeeResponse> getAllByManagementEntity(UUID managementEntity, Pageable pageable) {
        Page<Employee> employees = employeeRepository.findAllByManagementEntity(managementEntity, pageable);
        return employees.map(EmployeeMapper::map);
    }
}
