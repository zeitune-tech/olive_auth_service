package sn.zeitune.oliveinsuranceauthservice.app.entities;

public class RefreshToken {
}
