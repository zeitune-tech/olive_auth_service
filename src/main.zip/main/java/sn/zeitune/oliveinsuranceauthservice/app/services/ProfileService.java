package sn.zeitune.oliveinsuranceauthservice.app.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.ProfileRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.ProfileResponse;

import java.util.List;
import java.util.UUID;

public interface ProfileService {

    ProfileResponse create(ProfileRequest request);
    ProfileResponse update(UUID uuid, ProfileRequest request);
    void delete(UUID uuid);
    ProfileResponse getByUuid(UUID uuid);
    List<ProfileResponse> getAll();
    Page<ProfileResponse> getAll(Pageable pageable);
    List<ProfileResponse> getAllByManagementEntity(UUID managementEntity);
    Page<ProfileResponse> getAllByManagementEntity(UUID managementEntity, Pageable pageable);
}
