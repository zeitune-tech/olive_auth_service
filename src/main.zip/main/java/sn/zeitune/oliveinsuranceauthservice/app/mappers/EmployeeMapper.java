package sn.zeitune.oliveinsuranceauthservice.app.mappers;

import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.EmployeeRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.EmployeeResponse;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Employee;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Profile;

import java.util.Set;
import java.util.stream.Collectors;

public class EmployeeMapper {

    public static Employee map(EmployeeRequest request, Employee employee) {
        if (request == null) {
            return employee;
        }

        if (employee == null) {
            employee = new Employee();
        }
        employee.setFirstname(request.firstname());
        employee.setLastname(request.lastname());
        employee.setEmail(request.email());
        employee.setPassword(request.password());
        employee.setManagementEntity(request.managementEntity());

        return employee;
    }


    public static EmployeeResponse map(Employee employee) {
        if (employee == null) {
            return null;
        }
        return EmployeeResponse.builder()
                .uuid(employee.getUuid())
                .firstName(employee.getFirstname())
                .lastName(employee.getLastname())
                .email(employee.getEmail())
                .profiles(employee.getProfiles() != null ?
                        employee.getProfiles().stream().map(ProfileMapper::map).collect(Collectors.toSet())
                        : null)
                .managementEntity(employee.getManagementEntity())
                .build();
    }
}
