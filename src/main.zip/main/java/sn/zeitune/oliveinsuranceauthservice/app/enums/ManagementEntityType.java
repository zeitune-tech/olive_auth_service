package sn.zeitune.oliveinsuranceauthservice.app.enums;

public enum ManagementEntityType {
    COMPANY,
    MARKET_LEVEL_ORGANIZATION,
    POINT_OF_SALE
}
