package sn.zeitune.oliveinsuranceauthservice.app.enums;

public enum RestrictionType {
    ALLOWED,
    DENIED
}

