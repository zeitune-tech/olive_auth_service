package sn.zeitune.oliveinsuranceauthservice.app.enums;

public enum UserRole {
    ADMIN,
    USER
}
