package sn.zeitune.oliveinsuranceauthservice.app.services.impl;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.AdminRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.AdminResponse;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Admin;
import sn.zeitune.oliveinsuranceauthservice.app.mappers.AdminMapper;
import sn.zeitune.oliveinsuranceauthservice.app.repositories.AdminRepository;
import sn.zeitune.oliveinsuranceauthservice.app.services.AdminService;

import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class AdminServiceImpl implements AdminService {


    private final AdminRepository adminRepository;

    @Override
    public AdminResponse createAdmin(AdminRequest request) {
        Admin admin = AdminMapper.map(request, null);
        admin = adminRepository.save(admin);
        return AdminMapper.map(admin);
    }



    @Override
    public AdminResponse getAdminByUuid(UUID uuid) {
        Admin admin = adminRepository.findByUuid(uuid)
                .orElseThrow(() -> new RuntimeException("Admin not found for UUID: " + uuid));
        return AdminMapper.map(admin);
    }

    @Override
    public Page<AdminResponse> searchAdmins(Specification<Admin> spec, Pageable pageable) {
        return adminRepository.findAll(spec, pageable)
                .map(AdminMapper::map);
    }
}
