package sn.zeitune.oliveinsuranceauthservice.app.dto.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import sn.zeitune.oliveinsuranceauthservice.app.enums.ManagementEntityType;

@Builder
public record PermissionRequest(
        @NotBlank(message = "Le nom ne doit pas être vide")
        String name,

        String description,

        @NotNull(message = "Le type ne doit pas être nul")
        ManagementEntityType type
) {}
