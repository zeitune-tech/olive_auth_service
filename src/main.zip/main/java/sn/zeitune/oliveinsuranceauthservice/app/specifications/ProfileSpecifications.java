package sn.zeitune.oliveinsuranceauthservice.app.specifications;

import org.springframework.data.jpa.domain.Specification;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Profile;

import java.util.UUID;

public class ProfileSpecifications {

    public static Specification<Profile> hasUuid(UUID uuid) {
        return (root, query, cb) -> cb.equal(root.get("uuid"), uuid);
    }

    public static Specification<Profile> hasName(String name) {
        return (root, query, cb) -> cb.like(cb.lower(root.get("name")), "%" + name.toLowerCase() + "%");
    }

    public static Specification<Profile> hasManagementEntity(UUID managementEntity) {
        return (root, query, cb) -> cb.equal(root.get("managementEntity"), managementEntity);
    }
}
