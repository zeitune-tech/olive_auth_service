package sn.zeitune.oliveinsuranceauthservice.app.services.impl;


import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.zeitune.oliveinsuranceauthservice.app.dto.requests.ProfileRequest;
import sn.zeitune.oliveinsuranceauthservice.app.dto.responses.ProfileResponse;
import sn.zeitune.oliveinsuranceauthservice.app.entities.Profile;
import sn.zeitune.oliveinsuranceauthservice.app.exceptions.NotFoundException;
import sn.zeitune.oliveinsuranceauthservice.app.mappers.ProfileMapper;
import sn.zeitune.oliveinsuranceauthservice.app.repositories.ProfileRepository;
import sn.zeitune.oliveinsuranceauthservice.app.services.ProfileService;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class ProfileServiceImpl implements ProfileService {

    private final ProfileRepository profileRepository;

    @Override
    public ProfileResponse create(ProfileRequest request) {
        // Utilisation du mapper pour créer un nouveau Profile (en passant null pour l'instance existante)
        Profile profile = ProfileMapper.map(request, null);
        profile = profileRepository.save(profile);
        return ProfileMapper.map(profile);
    }

    @Override
    public ProfileResponse update(UUID uuid, ProfileRequest request) {
        // Récupération du profil existant via son UUID
        Profile profile = profileRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Profile not found for UUID: " + uuid));
        // Mise à jour de l'entité à partir du DTO
        ProfileMapper.map(request, profile);
        profile = profileRepository.save(profile);
        return ProfileMapper.map(profile);
    }

    @Override
    public void delete(UUID uuid) {
        Profile profile = profileRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Profile not found for UUID: " + uuid));
        profileRepository.delete(profile);
    }

    @Override
    @Transactional(readOnly = true)
    public ProfileResponse getByUuid(UUID uuid) {
        Profile profile = profileRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Profile not found for UUID: " + uuid));
        return ProfileMapper.map(profile);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProfileResponse> getAll() {
        return profileRepository.findAll().stream()
                .map(ProfileMapper::map)
                .collect(Collectors.toList());
    }

    @Override
    public Page<ProfileResponse> getAll(Pageable pageable) {
        return profileRepository.findAll(pageable)
                .map(ProfileMapper::map);
    }

    @Override
    public List<ProfileResponse> getAllByManagementEntity(UUID managementEntity) {
        List<Profile> profiles = profileRepository.findAllByManagementEntity(managementEntity);
        return profiles.stream()
                .map(ProfileMapper::map)
                .collect(Collectors.toList());
    }

    @Override
    public Page<ProfileResponse> getAllByManagementEntity(UUID managementEntity, Pageable pageable) {
        Page<Profile> profiles = profileRepository.findAllByManagementEntity(managementEntity, pageable);
        return profiles.map(ProfileMapper::map);
    }
}