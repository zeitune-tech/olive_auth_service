package sn.zeitune.oliveinsuranceauthservice.security;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import sn.zeitune.oliveinsuranceauthservice.app.enums.UserRole;

import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Service
public class KeyProviderService {

    @Value("${jwt.user.private-key}")
    private Resource userPrivateRes;
    @Value("${jwt.user.public-key}")
    private Resource publicRes;

    @Value("${jwt.admin.private-key}")
    private Resource adminPrivateRes;
    @Value("${jwt.admin.public-key}")
    private Resource adminPublicRes;

    public PrivateKey getPrivateKey(UserRole role) throws Exception {
        Resource res = role.equals(UserRole.ADMIN) ? adminPrivateRes : userPrivateRes;
        String key = new String(Files.readAllBytes(res.getFile().toPath()));
        key = key.replaceAll("-----\\w+ PRIVATE KEY-----", "").replaceAll("\\s", "");
        byte[] decoded = Base64.getDecoder().decode(key);
        return KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(decoded));
    }

    public PublicKey getPublicKey(UserRole role) throws Exception {
        Resource res = role.equals(UserRole.ADMIN) ? adminPublicRes : publicRes;

        String key = new String(Files.readAllBytes(res.getFile().toPath()));
        key = key.replaceAll("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll("-----END PUBLIC KEY-----", "")
                .replaceAll("\\s", "");

        byte[] decoded = Base64.getDecoder().decode(key);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(decoded);

        return KeyFactory.getInstance("RSA").generatePublic(keySpec);
    }
}
